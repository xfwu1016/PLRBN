#' @title PLAPLRML
#' @description Parallel linearization ADMM algorithm for solving penalized logistic regression under manual labeling
#' @param X Matrix of predictors, of dimension (n*p); each row is an observation.
#' @param S Manual labeling, when using real response variables, is equivalent to solving ordinary penalized logistic regression
#' @param D The number of local machines
#' @param lambda  Parameter tuning or regularization term parameters.
#' @param weights Weight of adaptive LASSO
#' @param m Number of manual labeling experts
#' @param mu Lagrange's quadratic augmented constant
#' @param eta Linearization parameters
#' @param max_iter Maximum number of algorithm iterations
#' @param tol Error parameters for algorithm termination
#' @returns \item{beta}{Regression coefficient.}
#' @returns \item{obj_values}{Optimization value of objective function.}
#' @returns \item{iterations}{number of iterations.}
#' @returns \item{time}{calculation time.}
#' @export
#' @examples
#' ######### Numerical experiments
#' library(glmnet)
#' library(Matrix)
#' library(gtools)#生成迪利克雷随机数所需要
#' rdirichletbinomial <- function(n=1, m, alpha0, Pr) {
#'   # 参数:
#'   # n: 样本量
#'   # m: 二项分布的试验次数
#'   # alpha0: Dirichlet分布的浓度参数
#'   # Pr: Dirichlet分布的基础概率向量
#'   
#'   # 生成Dirichlet随机变量
#'   p <- gtools::rdirichlet(n, alpha0 * Pr)
#'   
#'   # 从二项分布生成计数数据
#'   S <- sapply(1:n, function(i) rbinom(1, size = m, prob = p[i, 1]))
#'   
#'   # 返回结果
#'   list(p = p, S = S)
#' }#生成迪利克雷随机数
#' pite2=function(X,x,ite) #计算最大特征值函数
#' {
#'   x_m=matrix(0,nrow=ncol(X),ncol=ite+1)
#'   x_m[,1]=x
#'   k=0
#'   repeat{
#'     x_u=t(X)%*%(X%*%x_m[,k+1])
#'     x_u=x_u/sqrt(sum(x_u^2))
#'     lam_u= (sum((X%*%x_u)^2))
#'     k=k+1
#'     x_m[,k+1]=x_u
#'     err_a<-max(abs(x_m[,k+1]-x_m[,k]))
#'     if((err_a<0.001)|(k>ite-1)){break}
#'   }
#   
#'   return(lam_u)
#' }
#' set.seed(666666)
#' n <- 500  # 样本量
#' p <- 9   # 变量维度
#' 
#' # 生成设计矩阵X和真实系数beta
#' X <- matrix(rnorm(n * p), n, p)
#' true_beta <-  matrix(c(3,0,0,1.5,0,0,7,0,0),ncol=1)   # 稀疏系数
#' 
#' # 计算线性预测值并生成标签S
#' pp <- X %*% true_beta
#' prob <- 1 / (1 + exp(-pp))
#' S1 <- rbinom(n, 1, prob)  # 二元标签
#' 
#' 
#' 
#' 
#' alpha0 = 1
#' m <- 50
#' #
#' y = rbinom(n, 1, prob)
#' S2 = rep(0,n)
#' for (i in 1:n) {
#'   S2[i] = rdirichletbinomial(n = 1, m, alpha0, c(prob[i], 1-prob[i]))$S
#' }
#' 
#' #S <- rbinom(n, m, prob)
#' # 参数设置
#' #
#' cv.fit <- cv.glmnet(X, S1, family = "binomial", alpha = 1)
#' lambda_opt <- cv.fit$lambda.min
#' # 使用最优的 lambda 值获取模型系数
#' coef_opt <- coef(cv.fit, s = lambda_opt) #lambda_opt
#' weights <- 1/(abs(coef_opt[-1])+ 0.01)  # L1权重（可以调整）
#' lambda1 = 2
#' eta <-0.7*pite2(X,x=rep(1,ncol(X)),ite=100)[1]  #norm(t(X) %*% X, "2") * rho * 1.1  # 线性化参数（tau > rho*||X'X||）
#' # Ordinary Penalized Logistic Regression
#'  result0 <- PLAPLRML(X, y, D=1, lambda1, weights, m = 1 , 
#'          mu=1, eta = eta , max_iter=1000, tol=1e-3)
#'
#' result0$beta
#' result0$time
#' result0$iterations
#' # Penalized logistic regression with manual labeling by a single expert
#' result1 <- PLAPLRML(X, S1, D=1, lambda1, weights, m = 1 , 
#'                            mu=1, eta = eta , max_iter=1000, tol=1e-3)
#'
#' result1$beta
#' result1$time
#' result1$iterations
#' # Penalized logistic regression with manual labeling by multiple experts
#' lambda2 = 60
#' result2 <- PLAPLRML(X, S2, D=1, lambda2, weights, m  , 
#'                            mu=1, eta = eta , max_iter=1000, tol=1e-3)
#' result2$beta
#' sum(true_beta - result2$beta)
#' result2$time
#' result2$iterations
#' 
#' # ----------------------------
#' # 3. 结果可视化
#' # ----------------------------
#' # 绘制目标函数下降曲线
#' plot(result2$obj_values, type='l', xlab="Iteration", ylab="Objective Value",
#'      main="Objective Function Convergence")
#' 
#' # 比较估计的beta和真实beta
#' library(ggplot2)
#' df <- data.frame(
#'   index = 1:p,
#'   true = true_beta,
#'   estimated = result2$beta
#' )
#' 
#' ggplot(df, aes(x=index)) +
#'   geom_point(aes(y=true, color="True"), size=3) +
#'   geom_point(aes(y=estimated, color="Estimated"), size=3) +
#'   labs(title="True vs Estimated Coefficients", 
#'        y="Coefficient Value", x="Variable Index") +
#'   scale_color_manual(values=c("True"="red", "Estimated"="blue")) +
#'   theme_minimal()


PLAPLRML<- function(X, S, D, lambda, weights, m, 
                          mu, eta, max_iter=1000, tol=1e-3) {
  begin_tot <- proc.time()
  n <- nrow(X)
  p <- ncol(X)
  
  #数据分组
  group <- list()
  if(D>1){
    for (aa in 1:(D-1)) {
      group[[aa]] <- (1:n)[(floor(n/D)*(aa-1)+1) : (floor(n/D)*aa)]
    }}
  group[[D]] = (1:n)[(floor(n/D)*(D-1)+1):n]
  # 初始化变量
  beta <- rep(0, p)
  r <- rep(0, n)
  u <- rep(0, n)
  
  # 预计算X'X和X'用于加速
  #XtX <- crossprod(X)
  Xt <- t(X)
  
  ### eta值的更新
  #
  #if(n>p){mu=1/n}else{mu=1/p}#1/n#p>n 10^-5
  
  ETA = rep(0,D)
  ETA_t = rep(0,D)
  if(length(eta)==0){
    for (d in 1:D) {
      begin <- proc.time()
      ETA[d]=pite2(X[group[[d]],],x=rep(1,ncol(X)),ite=100)[1]
      end <- proc.time()
      ETA_t[d] =  (end - begin)[3]  
    }
    
    ETA = mu*ETA
    if(D<50){
      eta=0.7*sum(ETA)/sqrt(D)}else{eta=sum(ETA)/sqrt(2*D)}}
  time_xxk=matrix(0,D,max_iter + 1)
  
  
  # 保存目标函数值
  obj_values <- numeric(max_iter)
  r_prev = rep(0,n)
  # 主循环
  for (k in 1:max_iter) {
    # ----------------------------
    # 更新r（逻辑回归部分）
    # ----------------------------
    XX_k = 0
    for (d in 1:D) {
      begin <- proc.time()
      max_newton <- 10
      tol_newton <- 1e-4
      
      
      for (i in 1:length(group[[d]])) {
        r_old <- r[group[[d]]][i]
        for (newton_iter in 1:max_newton) {
          exp_r <- exp(r_old)
          grad <- -S[group[[d]]][i] + m * exp_r / (1 + exp_r) + mu * (r_old - X[group[[d]],][i,] %*% beta + u[group[[d]]][i])
          hess <- m * exp_r / (1 + exp_r)^2 + mu
          r_new <- r_old - grad / hess
          if (abs(r_new - r_old) < tol_newton) break
          r_old <- r_new
        }
        r[group[[d]]][i] <- r_new
      }
      XX_k = XX_k +  t(X[group[[d]],])%*%(X[group[[d]],]%*%beta - r[group[[d]]] - u[group[[d]]]/mu)
      end <- proc.time()
      time_xxk[d,k]=(end-begin)[3]
    }
    # ----------------------------
    # 更新beta（L1正则化部分）
    # ----------------------------
    # 计算线性化梯度步
    v <- beta - (mu/eta) * XX_k
    
    # 近端算子（软阈值）
    beta <- sign(v) * pmax(abs(v) - lambda * weights / eta, 0)
    
    # ----------------------------
    # 更新对偶变量u
    # ----------------------------
    u <- u + mu*r - mu*X %*% beta
    
    # ----------------------------
    # 计算目标函数值
    # ----------------------------
    # 逻辑回归损失
    loss_logistic <- sum(-S * r + m * log(1 + exp(r)))
    
    # L1正则化项
    penalty <- lambda * sum(weights * abs(beta))
    
    # 总目标函数
    obj_values[k] <- loss_logistic + penalty
    
    # ----------------------------
    # 检查收敛
    # ----------------------------
    primal_resid <- norm(r - X %*% beta, "2")
    dual_resid <- mu * norm(Xt %*% (r - r_prev), "2")  # 需要保存上一步的r##
    
    if (k > 1 && primal_resid < tol && dual_resid < tol) {
      obj_values <- obj_values[1:k]  # 截断
      break
    }
    
    r_prev <- r  # 保存当前r用于下次计算对偶残差
  }
  end_tot <- proc.time()
  Tol = (end_tot-begin_tot)[3]
  maxtime_xxk = 0
  for (j in 1:max_iter) {
    maxtime_xxk = maxtime_xxk + max(time_xxk[,j]);
  }
  
  
  result = list(beta=beta, obj_values=obj_values, iterations=k,time= Tol - sum(time_xxk) +
                  maxtime_xxk  -sum(ETA_t) + max(ETA_t))
  return(result)
  
}


